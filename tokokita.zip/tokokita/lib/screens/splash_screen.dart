import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '/screens/login.dart'; // Ubah dengan import yang sesuai

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigateToHome(); // Panggil fungsi untuk berpindah ke halaman utama setelah jangka waktu tertentu
  }

  Future<void> _navigateToHome() async {
    await Future.delayed(Duration(seconds: 3)); // Menunggu selama 3 detik

    // Pindah ke halaman utama
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => LoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Menyembunyikan status bar dan tombol navigasi di splash screen
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);

    return Scaffold(
      backgroundColor: Colors.blue, // Ubah warna sesuai preferensi Anda
      body: Center(
        child: Text(
          'Aplikasi Kantin',
          style: TextStyle(
            fontSize: 24,
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    // Mengembalikan tampilan status bar dan tombol navigasi setelah splash screen ditutup
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: SystemUiOverlay.values);
    super.dispose();
  }
}
