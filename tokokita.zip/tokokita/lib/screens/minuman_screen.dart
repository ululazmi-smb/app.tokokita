import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:tokokita/modul/url.dart';
import 'package:tokokita/screens/tambah_makanan_screen.dart';
import 'package:tokokita/screens/edit_makanan_screen.dart';
import 'dart:convert';

class MinumanScreen extends StatefulWidget {
  @override
  _MinumanScreenState createState() => _MinumanScreenState();
}

class _MinumanScreenState extends State<MinumanScreen> {
  List<MakananItem> makananList = [];

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    final url = '${Url.read_minuman}'; // Ganti dengan URL API Anda
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);

      // Membuat daftar makanan dari data yang diperoleh
      List<MakananItem> tempList = [];
      for (var item in data) {
        tempList.add(MakananItem(
          id: item['id'],
          nama: item['nama'],
          stok: int.parse(item['stok']),
          harga: item['harga'],
          type: item['type'],
          onDelete: () => deleteItem(item['id']),
          onEdit: () => editItem(item),
        ));
      }

      // Mengupdate state dengan daftar makanan yang diperoleh
      setState(() {
        makananList = tempList;
      });
    } else {
      // Gagal mengambil data, Anda dapat menangani sesuai kebutuhan
      print('Gagal mengambil data');
    }
  }

  Future<void> deleteItem(String id) async {
    final url = '${Url.delete_makanan}/$id'; // Ganti dengan URL API Anda
    final response = await http.delete(Uri.parse(url));

    if (response.statusCode == 200) {
      // Hapus item berhasil
      print('Item dengan ID $id berhasil dihapus');
      // Lakukan refresh data setelah penghapusan item
      fetchData();
    } else {
      // Gagal menghapus item
      print('Gagal menghapus item');
    }
  }

  void editItem(dynamic item) {
    // Lakukan navigasi ke layar EditMakananScreen dengan data item yang akan diedit
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditMakananScreen(item: item),
      ),
    ).then((_) {
      // Lakukan refresh data setelah pengeditan item
      fetchData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Minuman'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TambahMakananScreen(),
                ),
              ).then((_) {
                // Lakukan refresh data setelah menambahkan item baru
                fetchData();
              });
            },
          ),
        ],
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(16.0),
        itemCount: makananList.length,
        itemBuilder: (BuildContext context, int index) {
          return makananList[index];
        },
      ),
    );
  }
}

class MakananItem extends StatelessWidget {
  final String id;
  final String nama;
  final int stok;
  final String harga;
  final String type;
  final Function onDelete;
  final Function onEdit;

  const MakananItem({
    required this.id,
    required this.nama,
    required this.stok,
    required this.harga,
    required this.type,
    required this.onDelete,
    required this.onEdit,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              nama,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Text('Stok: $stok'),
            SizedBox(height: 8.0),
            Text('Harga: $harga'),
            SizedBox(height: 16.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => onEdit(),
                  child: Text('Edit'),
                ),
                ElevatedButton(
                  onPressed: () => onDelete(),
                  child: Text('Hapus'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
