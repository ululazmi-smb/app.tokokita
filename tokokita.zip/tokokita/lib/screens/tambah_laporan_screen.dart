import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:tokokita/modul/url.dart';

class InputDataPage extends StatefulWidget {
  @override
  _InputDataPageState createState() => _InputDataPageState();
}

class _InputDataPageState extends State<InputDataPage> {
  final DateFormat _dateFormat = DateFormat('yyyy-MM-dd');
  TextEditingController _tanggalController = TextEditingController();
  TextEditingController _deskripsiController = TextEditingController();
  TextEditingController _jumlahController = TextEditingController();
  String _jenisLaporan = 'masuk';

  List<String> _jenisLaporanOptions = ['masuk', 'keluar'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Input Data'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextFormField(
              controller: _tanggalController,
              decoration: InputDecoration(
                labelText: 'Tanggal',
                suffixIcon: IconButton(
                  icon: Icon(Icons.calendar_today),
                  onPressed: () {
                    _selectDate(context);
                  },
                ),
              ),
              readOnly: true,
              onTap: () {
                _selectDate(context);
              },
            ),
            TextField(
              controller: _deskripsiController,
              decoration: InputDecoration(labelText: 'Deskripsi'),
            ),
            TextField(
              controller: _jumlahController,
              decoration: InputDecoration(labelText: 'Jumlah'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16.0),
            DropdownButton<String>(
              value: _jenisLaporan,
              onChanged: (String? newValue) {
                setState(() {
                  _jenisLaporan = newValue!;
                });
              },
              items: _jenisLaporanOptions.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                String tanggal = _tanggalController.text;
                String deskripsi = _deskripsiController.text;
                String jumlah = _jumlahController.text;

                // Membuat objek Map dengan data yang akan dikirim
                Map<String, dynamic> postData = {
                  'tanggal': tanggal,
                  'deskripsi': deskripsi,
                  'jumlah': jumlah,
                  'jenis_laporan': _jenisLaporan,
                };

                _postData(postData);
              },
              child: Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }

  void _postData(Map<String, dynamic> data) async {
    final url = Uri.parse('${Url.insert_laproan}');

    final response = await http.post(
      url,
      body: data,
    );

    print(response.body);
    if (response.statusCode == 200) {
      // Data berhasil dikirim
      print('Data berhasil dikirim');
      // Kembali ke halaman sebelumnya
      Navigator.pop(context);
    } else {
      // Gagal mengirim data
      print('Gagal mengirim data');
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (picked != null) {
      setState(() {
        _tanggalController.text = _dateFormat.format(picked);
      });
    }
  }
}