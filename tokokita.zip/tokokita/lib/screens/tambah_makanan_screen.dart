import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:tokokita/modul/url.dart';

class TambahMakananScreen extends StatefulWidget {
  @override
  _TambahMakananScreenState createState() => _TambahMakananScreenState();
}

class _TambahMakananScreenState extends State<TambahMakananScreen> {
  TextEditingController _namaController = TextEditingController();
  TextEditingController _stokController = TextEditingController();
  TextEditingController _hargaController = TextEditingController();
  String _selectedType = 'makanan'; // Default selected type

  @override
  void dispose() {
    _namaController.dispose();
    _stokController.dispose();
    _hargaController.dispose();
    super.dispose();
  }

  Future<void> tambahMakanan(String nama, int stok, String harga, String type) async {
    final url = '${Url.insert}'; // Replace with your API URL

    final body = {
      'nama': nama,
      'stok': stok.toString(),
      'harga': harga,
      'type': type,
    };

    final response = await http.post(
      Uri.parse(url),
      body: body,
    );

    if (response.statusCode == 200) {
      // Successfully added makanan
      print('${type} berhasil ditambahkan');

      // Go back to the previous page
      Navigator.pop(context);
    } else {
      // Failed to add makanan
      print('Gagal menambahkan ${type} ');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tambah'),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          TextField(
            controller: _namaController,
            decoration: InputDecoration(
              labelText: 'Nama',
            ),
          ),
          SizedBox(height: 16.0),
          TextField(
            controller: _stokController,
            decoration: InputDecoration(
              labelText: 'Stok',
            ),
            keyboardType: TextInputType.number,
          ),
          SizedBox(height: 16.0),
          TextField(
            controller: _hargaController,
            decoration: InputDecoration(
              labelText: 'Harga',
            ),
            keyboardType: TextInputType.number,
          ),
          SizedBox(height: 16.0),
          DropdownButton<String>(
            value: _selectedType,
            onChanged: (String? newValue) {
              setState(() {
                _selectedType = newValue!;
              });
            },
            items: [
              DropdownMenuItem<String>(
                value: 'makanan',
                child: Text('Makanan'),
              ),
              DropdownMenuItem<String>(
                value: 'minuman',
                child: Text('Minuman'),
              ),
              DropdownMenuItem<String>(
                value: 'snack',
                child: Text('Snack'),
              ),
            ],
          ),
          SizedBox(height: 16.0),
          ElevatedButton(
            onPressed: () {
              String nama = _namaController.text;
              int stok = int.tryParse(_stokController.text) ?? 0;
              String harga = _hargaController.text;

              tambahMakanan(nama, stok, harga, _selectedType);
            },
            child: Text('Simpan'),
          ),
        ],
      ),
    );
  }
}
