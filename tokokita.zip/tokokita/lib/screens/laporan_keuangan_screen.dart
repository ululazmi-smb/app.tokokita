import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:tokokita/modul/url.dart';
import 'package:tokokita/screens/tambah_laporan_screen.dart';
import 'dart:convert';

class LaporanKeuanganScreen extends StatefulWidget {
  @override
  _LaporanKeuanganScreenState createState() => _LaporanKeuanganScreenState();
}

class _LaporanKeuanganScreenState extends State<LaporanKeuanganScreen> {
  List<DataRow> pemasukanList = [];
  List<DataRow> pengeluaranList = [];
  double totalPemasukan = 0;
  double totalPengeluaran = 0;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    final pemasukanUrl = '${Url.read_masuk}'; // Replace with your API URL for pemasukan data
    final pengeluaranUrl = '${Url.read_keluar}'; // Replace with your API URL for pengeluaran data

    final pemasukanResponse = await http.get(Uri.parse(pemasukanUrl));
    final pengeluaranResponse = await http.get(Uri.parse(pengeluaranUrl));

    if (pemasukanResponse.statusCode == 200 && pengeluaranResponse.statusCode == 200) {
      final pemasukanData = jsonDecode(pemasukanResponse.body);
      final pengeluaranData = jsonDecode(pengeluaranResponse.body);

      // Parse pemasukan data
      List<DataRow> pemasukanRows = [];
      double pemasukanTotal = 0;
      for (var item in pemasukanData) {
        double jumlah = double.parse(item['jumlah']);
        pemasukanRows.add(
          DataRow(
            cells: <DataCell>[
              DataCell(Text(item['tanggal'])),
              DataCell(Text(item['deskripsi'])),
              DataCell(Text('Rp ${item['jumlah']}')),
            ],
          ),
        );
        pemasukanTotal += jumlah;
      }

      // Parse pengeluaran data
      List<DataRow> pengeluaranRows = [];
      double pengeluaranTotal = 0;
      for (var item in pengeluaranData) {
        double jumlah = double.parse(item['jumlah']);
        pengeluaranRows.add(
          DataRow(
            cells: <DataCell>[
              DataCell(Text(item['tanggal'])),
              DataCell(Text(item['deskripsi'])),
              DataCell(Text('Rp ${item['jumlah']}')),
            ],
          ),
        );
        pengeluaranTotal += jumlah;
      }

      setState(() {
        pemasukanList = pemasukanRows;
        pengeluaranList = pengeluaranRows;
        totalPemasukan = pemasukanTotal;
        totalPengeluaran = pengeluaranTotal;
      });
    } else {
      // Failed to fetch data, handle the error
      print('Failed to fetch data');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Makanan'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => InputDataPage(),
                ),
              ).then((_) {
                // Lakukan refresh data setelah menambahkan item baru
                fetchData();
              });
            },
          ),
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            'Tabel Pemasukan',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16.0),
          DataTable(
            columns: const <DataColumn>[
              DataColumn(
                label: Text(
                  'Tanggal',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              DataColumn(
                label: Text(
                  'Deskripsi',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              DataColumn(
                label: Text(
                  'Jumlah',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ],
            rows: pemasukanList,
          ),
          SizedBox(height: 16.0),
          Text(
            'Total Pemasukan: Rp $totalPemasukan',
            style: TextStyle(fontSize: 16),
          ),
          SizedBox(height: 32.0),
          Text(
            'Tabel Pengeluaran',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16.0),
          DataTable(
            columns: const <DataColumn>[
              DataColumn(
                label: Text(
                  'Tanggal',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              DataColumn(
                label: Text(
                  'Deskripsi',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              DataColumn(
                label: Text(
                  'Jumlah',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ],
            rows: pengeluaranList,
          ),
          SizedBox(height: 16.0),
          Text(
            'Total Pengeluaran: Rp $totalPengeluaran',
            style: TextStyle(fontSize: 16),
          ),
          SizedBox(height: 32.0),
          Text(
            'Keuntungan: Rp ${totalPemasukan - totalPengeluaran}',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}
