import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:tokokita/modul/url.dart';
import 'dart:convert';

class EditMakananScreen extends StatefulWidget {
  final dynamic item;

  EditMakananScreen({required this.item});

  @override
  _EditMakananScreenState createState() => _EditMakananScreenState();
}

class _EditMakananScreenState extends State<EditMakananScreen> {
  TextEditingController namaController = TextEditingController();
  TextEditingController stokController = TextEditingController();
  TextEditingController hargaController = TextEditingController();
  String selectedType = 'makanan'; // Default selected type
  List<String> typeOptions = ['makanan', 'minuman', 'snack'];

  @override
  void initState() {
    super.initState();
    // Fill the controller with the initial values from the item
    namaController.text = widget.item['nama'];
    stokController.text = widget.item['stok'].toString();
    hargaController.text = widget.item['harga'];
    selectedType = widget.item['type'];
  }

  Future<void> updateItem() async {
    final url = '${Url.edit}/${widget.item['id']}'; // Replace with your API URL
    final response = await http.post(Uri.parse(url), body: {
      'nama': namaController.text,
      'stok': stokController.text,
      'harga': hargaController.text,
      'type': selectedType,
    });
    if (response.statusCode == 200) {
      // Item successfully updated
      print('Item berhasil diperbarui');
      Navigator.pop(context); // Go back to the previous screen
    } else {
      // Failed to update item
      print('Gagal memperbarui item');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextFormField(
              controller: namaController,
              decoration: InputDecoration(labelText: 'Nama'),
            ),
            TextFormField(
              controller: stokController,
              decoration: InputDecoration(labelText: 'Stok'),
              keyboardType: TextInputType.number,
            ),
            TextFormField(
              controller: hargaController,
              decoration: InputDecoration(labelText: 'Harga'),
            ),
            SizedBox(height: 16.0),
            DropdownButton<String>(
              value: selectedType,
              onChanged: (String? newValue) {
                setState(() {
                  selectedType = newValue!;
                });
              },
              items: typeOptions.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                updateItem();
              },
              child: Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }
}
