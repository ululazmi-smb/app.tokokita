class Url {
  static const String dasar = 'http://10.4.254.211/app.tokokita';
  static const String login = '${Url.dasar}/api/login';
  static const String register = '${Url.dasar}/api/login/register';
  static const String read_makanan = '${Url.dasar}/api/menu/read/makanan';
  static const String read_minuman = '${Url.dasar}/api/menu/read/minuman';
  static const String read_snack = '${Url.dasar}/api/menu/read/snack';
  static const String insert = '${Url.dasar}/api/menu/insert';
  static const String edit = '${Url.dasar}/api/menu/edit';
  static const String delete_makanan = '${Url.dasar}/api/menu/delete_makanan';
  static const String read_masuk = '${Url.dasar}/api/Laporan/index/masuk';
  static const String read_keluar = '${Url.dasar}/api/Laporan/index/keluar';
  static const String insert_laproan = '${Url.dasar}/api/Laporan/insert';
}