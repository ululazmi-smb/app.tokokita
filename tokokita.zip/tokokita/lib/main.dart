// Import yang diperlukan
import 'package:flutter/material.dart';
import '/screens/login.dart'; // Ubah dengan import yang sesuai

void main() => runApp(KantinApp());

class KantinApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplikasi Kantin',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginScreen(), // Ubah halaman utama menjadi LoginScreen()
    );
  }
}
