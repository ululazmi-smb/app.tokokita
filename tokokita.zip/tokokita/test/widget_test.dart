// Import yang diperlukan
import 'package:flutter/material.dart';
import 'package:tokokita/screens/login.dart'; // Ubah dengan import yang sesuai

void main() => runApp(Tokokita());

class Tokokita extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplikasi Kantin',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginScreen(), // Ubah halaman utama menjadi LoginScreen()
    );
  }
}
